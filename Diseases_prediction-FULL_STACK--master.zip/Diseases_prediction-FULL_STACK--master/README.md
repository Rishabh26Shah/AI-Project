# DIESEASES PREDICTION IN FULL STACK

For the disease prediction, we use Naive bayes as well as Decision tree machine learning algorithm for accurate prediction of disease. For disease prediction required disease symptoms dataset.


Also, we have used python as a backend for making full stack development
